This project runs on an Adafruit ESP32 board and uses asyncio to manage all background tasks. The ESP32 connects to Wi-Fi, then sets up a topic on an MQTT broker.

A DHT11 sensor is read periodically, and the code calculates the average temperature and humidity values. These values are then published to the MQTT topic.

The program also cheks for incoming MQTT messages to see if any data has been received on the subscribed topic.

Overall, the project demonstrates how to combine asyncio, Wi-Fi connectivity, MQTT communication, and DHT11 sensor readings.