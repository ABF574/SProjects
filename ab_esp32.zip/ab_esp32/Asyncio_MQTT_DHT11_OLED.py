import uasyncio as asyncio
from machine import Pin, I2C
import dht
import network
import time
from umqtt.simple import MQTTClient
import ssd1306

# Initialisation de l'I2C
oled_width = 128
oled_height = 64
i2c = I2C(0,scl=Pin(22), sda=Pin(23))

# initialisation de l'écran
oled = ssd1306.SSD1306_I2C(oled_width, oled_height, i2c, addr=0x3D)

# broche du capteur
sensor = dht.DHT11(Pin(27))

# listes pour la moyenne glissante sur 5 échantillons
temp_tab = [0] * 5
hum_tab = [0] * 5
temp_index = 0
hum_index = 0

# variables globales pour la moyenne
temp = 0
hum = 0
avg_temp = 0.0
avg_hum = 0.0

# configuration Wi-Fi
SSID = "wifi"
PASSWORD = "password"

# configuration MQTT
BROKER = "broker.hivemq.com"
PORT = 1883  # Port standard non sécurisé
CLIENT_ID = "esp32_client"
TOPIC = b"Topic_IoT"

# calculer la moyenne
def calcul_moy(L):
    return sum(L) / len(L)

# se connecter au Wi-Fi
async def connect_wifi(SSID, PASSWORD):
    try:
        wlan = network.WLAN(network.STA_IF)
        wlan.active(True)
        if not wlan.isconnected():
            wlan.connect(SSID, PASSWORD)
            print("Connexion au WiFi...")
            while not wlan.isconnected():
                await asyncio.sleep(1)
                print("Tentative de connexion...")
        print("Connexion au WiFi:", wlan.ifconfig())
    
    except OSError as e:
        print("Network error:", e)
    
# affichage sur l'OLED
async def OLED():
    global temp, hum, avg_temp, avg_hum
    while True:
        try:
            # moyenne glissante sur 5 échantillons
            avg_temp = calcul_moy(temp_tab)
            avg_hum = calcul_moy(hum_tab)
            
            # affichage des informations sur l'écran
            oled.fill(0)
            oled.text("Temp: {} C".format(temp),0,0)
            oled.text("Humidity: {} %".format(hum),0,20)
            oled.text("Temp moy: {:.2f} C".format(avg_temp), 0, 30)
            oled.text("Hum moy: {:.2f} %".format(avg_hum), 0, 40)
            oled.show()
        
            await asyncio.sleep(2)
        except:
            oled.fill(0)
            oled.text("Failed to read",0,0)
            oled.show()
            await asyncio.sleep(2)

# gestion des messages entrants
def message_callback(topic, msg):
    print("Nouveau message sur le topic {}: {}".format(topic, msg))

# connexion et configuration MQTT
def connect_mqtt():
    try:
        client = MQTTClient(CLIENT_ID, BROKER, PORT)
        client.set_callback(message_callback)
        client.connect()
        print("Connecté au broker MQTT:", BROKER)
        client.subscribe(TOPIC)
        print("Abonné au topic:", TOPIC.decode())
        return client
    except Exception as e:
        print("Erreur de connexion MQTT:", e)
        return None

# coroutine pour afficher les messages du capteur DHT11
async def DHT11():
    global temp, hum, temp_tab, hum_tab, temp_index, hum_index
    while True:
        try:
            sensor.measure()
            temp = sensor.temperature()
            hum = sensor.humidity()
            
            temp_tab[temp_index] = temp
            hum_tab[hum_index] = hum
            
            temp_index = (temp_index + 1) % 5
            hum_index = (hum_index + 1) % 5
            
            print("Temperature: {}° C, Humidite: {}%".format(temp, hum))
            await asyncio.sleep(5)
        except OSError as e:
            print("Erreur de lecture du capteur")

# coroutine pour publier les données MQTT
async def Publication(client):
    global temp, hum, avg_temp, avg_hum
    while True:
        try:
            message = "Temperature: {} C, Humidite: {}%".format(temp, hum)
            client.publish(TOPIC, message.encode())
            
            print("Premier message poste sur le topic:", TOPIC.decode())
            
            message = "Temperature moyenne: {:.2f} C, Humidite moyenne: {:.2f}%".format(avg_temp, avg_hum)
            client.publish(TOPIC, message.encode())
            
            print("Deuxieme message poste sur le topic:", TOPIC.decode())

            client.check_msg()  

            await asyncio.sleep(5) 

        except OSError as e:
            print("Network error:", e)
            await asyncio.sleep(10)

# fonction principale qui lance les deux coroutines
async def main():

    await connect_wifi(SSID, PASSWORD)

    client = connect_mqtt()

    task1 = asyncio.create_task(DHT11())
    task2 = asyncio.create_task(Publication(client))
    task3 = asyncio.create_task(OLED())
    
    await asyncio.gather(task1, task2, task3)

# exécution de la fonction principale
try:
    asyncio.run(main())
except KeyboardInterrupt:
    print("Arrêt du programme.")