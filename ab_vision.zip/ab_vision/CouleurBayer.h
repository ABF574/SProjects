#include <stdexcept>
#include <math.h>
#include <stdint.h>
#ifndef RGBdefined
typedef struct { uint8_t r, g, b; }   RGBval;
#define RGBdefined 
#endif

#define COPIE_PIXEL					5099
#define INTERPOLATION				5100
#define METHODE_3					5105
#define RG							5101
#define GR							5102
#define GB							5103
#define BG							5104



namespace TraitImageDll
{
	class couleurBayer
	{
	public:
		static __declspec(dllexport) void combinaison_Bayer(uint8_t** im, RGBval** imr, uint32_t dimx, uint32_t dimy, int debut);

	};
}