//#define _USE_MATH_DEFINES
#include <stdexcept>
#include <math.h>
#include <stdint.h>
#include "CouleurBayer.h"



using namespace std;

namespace TraitImageDll
{
	void couleurBayer::combinaison_Bayer(uint8_t **im, RGBval **imr, uint32_t dimx, uint32_t dimy, int debut)
	{
		int x, y;
				
		for (y = 2; y < dimy - 2; y++) {
			for (x = 2; x < dimx - 2; x++) {

				if ((y % 2 == 0) && (x % 2 == 1)) { // Pixel BLEU structure {GBG}
					imr[y][x].b = im[y][x];

					// calcul les differences horizontale/verticale pour pixel VERT
					double Dx = abs(im[y][x - 1] - im[y][x + 1]) + abs(2 * im[y][x] - im[y][x - 2] - im[y][x + 2]);
					double Dy = abs(im[y - 1][x] - im[y + 1][x]) + abs(2 * im[y][x] - im[y - 2][x] - im[y + 2][x]);

					// interpolation Laplace pixel VERT
					if (Dx < Dy) {
						imr[y][x].g = (im[y][x - 1] + im[y][x + 1]) / 2 + (2 * im[y][x] - im[y][x - 2] - im[y][x + 2]) / 4;
					}
					else if (Dx > Dy) {
						imr[y][x].g = (im[y - 1][x] + im[y + 1][x]) / 2 + (2 * im[y][x] - im[y - 2][x] - im[y + 2][x]) / 4;
					}
					else {
						imr[y][x].g = (im[y - 1][x] + im[y + 1][x] + im[y][x - 1] + im[y][x + 1]) / 4 +
							(4 * im[y][x] - im[y - 2][x] - im[y + 2][x] - im[y][x - 2] - im[y][x + 2]) / 8;
					}
						
					// calcul la difference ROUGE
					double Dn = abs(-(float)imr[y - 1][x - 1].g + 2 * (float)imr[y][x].g - (float)imr[y + 1][x + 1].g) + abs(im[y - 1][x - 1] - im[y + 1][x + 1]);
					double Dp = abs(-(float)imr[y - 1][x + 1].g + 2 * (float)imr[y][x].g - (float)imr[y + 1][x - 1].g) + abs(im[y - 1][x + 1] - im[y + 1][x - 1]);

					// interpolation Laplace pixel ROUGE
					if (Dx < Dy) {
						imr[y][x].r = ((float)imr[y - 1][x - 1].b + (float)imr[y + 1][x + 1].b) / 2 + (-(float)imr[y - 1][x - 1].g + 2 * (float)imr[y][x].g - (float)imr[y + 1][x + 1].g) / 2;
					}
					else if (Dx > Dy) {
						imr[y][x].r = ((float)imr[y - 1][x + 1].b + (float)imr[y + 1][x - 1].b) / 2 + (-(float)imr[y - 1][x + 1].g + 2 * (float)imr[y][x].g - (float)imr[y + 1][x - 1].g) / 2;
					} 
					else {
						imr[y][x].r = ((float)imr[y - 1][x - 1].b + (float)imr[y + 1][x + 1].b + (float)imr[y - 1][x + 1].b + (float)imr[y + 1][x - 1].b) / 4 +
							(-(float)imr[y - 1][x - 1].g - (float)imr[y - 1][x + 1].g + 4 * (float)imr[y][x].g - (float)imr[y + 1][x - 1].g - (float)imr[y + 1][x + 1].g) / 4;
					}
				}
				else if ((y % 2 == 1) && (x % 2 == 0)) { // Pixel ROUGE structure {GRG}
					imr[y][x].r = im[y][x];

					// calcul les differences horizontale/verticale pour pixel VERT
					double Dx = abs(im[y][x - 1] - im[y][x + 1]) + abs(2 * im[y][x] - im[y][x - 2] - im[y][x + 2]);
					double Dy = abs(im[y - 1][x] - im[y + 1][x]) + abs(2 * im[y][x] - im[y - 2][x] - im[y + 2][x]);

					// interpolation Laplace pixel vert
					if (Dx < Dy) {
						imr[y][x].g = (im[y][x - 1] + im[y][x + 1]) / 2 + (2 * im[y][x] - im[y][x - 2] - im[y][x + 2]) / 4;
					}
					else if (Dx > Dy) {
						imr[y][x].g = (im[y - 1][x] + im[y + 1][x]) / 2 + (2 * im[y][x] - im[y - 2][x] - im[y + 2][x]) / 4;
					}
					else {
						imr[y][x].g = (im[y - 1][x] + im[y + 1][x] + im[y][x - 1] + im[y][x + 1]) / 4 +
							(4 * im[y][x] - im[y - 2][x] - im[y + 2][x] - im[y][x - 2] - im[y][x + 2]) / 8;
					}

					// calcul les differences diagonales pour pixel BLEU
					double Dn = abs(-(float)imr[y - 1][x - 1].g + 2 * (float)imr[y][x].g - (float)imr[y + 1][x + 1].g) + abs(im[y - 1][x - 1] - im[y + 1][x + 1]);
					double Dp = abs(-(float)imr[y - 1][x + 1].g + 2 * (float)imr[y][x].g - (float)imr[y + 1][x - 1].g) + abs(im[y - 1][x + 1] - im[y + 1][x - 1]);

					// interpolation Laplace pixel BLEU
					if (Dx < Dy) {
						imr[y][x].b = ((float)imr[y - 1][x - 1].r + (float)imr[y + 1][x + 1].r) / 2 + (-(float)imr[y - 1][x - 1].g + 2 * (float)imr[y][x].g - (float)imr[y + 1][x + 1].g) / 2;
					}
					else if (Dx > Dy) {
						imr[y][x].b = ((float)imr[y - 1][x + 1].r + (float)imr[y + 1][x - 1].r) / 2 + (-(float)imr[y - 1][x + 1].g + 2 * (float)imr[y][x].g - (float)imr[y + 1][x - 1].g) / 2;
					}
					else {
						imr[y][x].b = ((float)imr[y - 1][x - 1].r + (float)imr[y + 1][x + 1].r + (float)imr[y - 1][x + 1].r + (float)imr[y + 1][x - 1].r) / 4 +
							(-(float)imr[y - 1][x - 1].g - (float)imr[y - 1][x + 1].g + 4 * (float)imr[y][x].g - (float)imr[y + 1][x - 1].g - (float)imr[y + 1][x + 1].g) / 4;
					}
				}
			}
		}
		
	}

}