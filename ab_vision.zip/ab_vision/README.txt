This program implements the directional interpolation method using the gradient-corrected Laplacian, as described by Hamilton and Adams in Hamilton97. The approach follows the concepts outlined in patent US5629734A.

The implementation is written in C++ and demonstrates the core ideas of the method. It can serve as an example of how this interpolation technique can be applied in practice.